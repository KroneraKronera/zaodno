import {
  Router,
  type IRouter,
  type NextFunction,
  type Request,
  type RequestHandler,
  type Response,
} from "express";
import {
  GetGigaChatStatusResponse,
  InterpretIntentBody,
  InterpretIntentResponse,
} from "@workspace/api-zod";
import {
  GigaChatRequestError,
  getAccessToken,
  getGigaChatConfig,
  interpretDemo,
  interpretWithGigaChat,
} from "../lib/gigachat";

const router: IRouter = Router();
const requestWindows = new Map<
  string,
  { count: number; resetAt: number }
>();

function rateLimit(limit: number, windowMs: number): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    const now = Date.now();
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const current = requestWindows.get(key);
    const window =
      !current || current.resetAt <= now
        ? { count: 0, resetAt: now + windowMs }
        : current;
    window.count += 1;
    requestWindows.set(key, window);

    if (window.count > limit) {
      const retryAfterSeconds = Math.max(
        1,
        Math.ceil((window.resetAt - now) / 1000),
      );
      res.setHeader("Retry-After", retryAfterSeconds.toString());
      req.log.warn(
        { provider: "gigachat", retryAfterSeconds },
        "GigaChat rate limit exceeded",
      );
      res.status(429).json({ error: "Слишком много запросов. Попробуйте позже." });
      return;
    }
    next();
  };
}

function safeErrorDetails(error: unknown) {
  if (error instanceof GigaChatRequestError) {
    return {
      errorName: error.name,
      stage: error.stage,
      status: error.status,
      validationFields: error.validationFields,
    };
  }
  return {
    errorName: error instanceof Error ? error.name : "UnknownError",
    stage: "unknown",
    status: null,
  };
}

function safeClientMessage(error: unknown): string {
  if (error instanceof GigaChatRequestError) {
    if (error.status) {
      return `Сбой на этапе ${error.stage}, HTTP ${error.status}`;
    }
    return `Сбой на этапе ${error.stage}`;
  }
  return "Неизвестная ошибка GigaChat";
}

function isRetryableGigaChatError(error: unknown): boolean {
  if (!(error instanceof GigaChatRequestError)) return false;
  if (error.stage === "structured_output") return true;
  if (error.stage !== "completion") return false;
  return (
    error.status === null ||
    error.status === 429 ||
    (error.status >= 500 && error.status <= 599)
  );
}

router.get(
  "/gigachat/status",
  rateLimit(60, 10 * 60 * 1000),
  async (req, res): Promise<void> => {
  const config = getGigaChatConfig();
  if (!config.configured) {
    req.log.warn(
      { provider: "gigachat", diagnostic: "demo fallback" },
      "GigaChat is not configured",
    );
    res.json(
      GetGigaChatStatusResponse.parse({
        status: "demo",
        configured: false,
        model: config.model,
        diagnostic: "demo fallback",
        message: "GigaChat не настроен",
      }),
    );
    return;
  }

  try {
    await getAccessToken();
    req.log.info(
      { provider: "gigachat", diagnostic: "GigaChat connected" },
      "GigaChat OAuth check succeeded",
    );
    res.json(
      GetGigaChatStatusResponse.parse({
        status: "connected",
        configured: true,
        model: config.model,
        diagnostic: "GigaChat connected",
        message: null,
      }),
    );
  } catch (error) {
    req.log.error(
      {
        provider: "gigachat",
        diagnostic: "GigaChat error",
        ...safeErrorDetails(error),
      },
      "GigaChat OAuth check failed",
    );
    res.json(
      GetGigaChatStatusResponse.parse({
        status: "error",
        configured: true,
        model: config.model,
        diagnostic: "GigaChat error",
        message: safeClientMessage(error),
      }),
    );
  }
  },
);

router.post(
  "/interpret",
  rateLimit(30, 10 * 60 * 1000),
  async (req, res): Promise<void> => {
  const parsed = InterpretIntentBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn(
      { validationIssueCount: parsed.error.issues.length },
      "Invalid interpretation request",
    );
    res.status(400).json({ error: "Некорректный запрос" });
    return;
  }

  const config = getGigaChatConfig();
  const input = {
    text: parsed.data.text,
    familyMembers: parsed.data.familyMembers,
    nowIso: parsed.data.nowIso?.toISOString() ?? new Date().toISOString(),
  };

  if (!config.configured) {
    req.log.warn(
      { provider: "demo", diagnostic: "demo fallback" },
      "Using explicit demo fallback because GigaChat is not configured",
    );
    res.json(InterpretIntentResponse.parse(interpretDemo(input)));
    return;
  }

  try {
    let result;
    try {
      result = await interpretWithGigaChat(input);
    } catch (error) {
      if (!isRetryableGigaChatError(error)) throw error;
      req.log.warn(
        {
          provider: "gigachat",
          diagnostic: "GigaChat error",
          retry: 1,
          ...safeErrorDetails(error),
        },
        "Retrying GigaChat interpretation",
      );
      result = await interpretWithGigaChat(input);
    }
    req.log.info(
      {
        provider: "gigachat",
        diagnostic: "GigaChat connected",
        actionCount: result.actions.length,
        itemCount: result.actions.reduce(
          (count, action) => count + action.items.length,
          0,
        ),
      },
      "GigaChat interpretation succeeded",
    );
    res.json(InterpretIntentResponse.parse(result));
  } catch (error) {
    req.log.error(
      {
        provider: "gigachat",
        diagnostic: "GigaChat error",
        ...safeErrorDetails(error),
      },
      "GigaChat interpretation failed",
    );
    res.status(502).json({
      error: "GigaChat unavailable",
      diagnostic: "GigaChat error",
      message: safeClientMessage(error),
    });
  }
  },
);

export default router;
