import { Router, type IRouter } from "express";
import healthRouter from "./health";
import gigachatRouter from "./gigachat";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gigachatRouter);

export default router;
