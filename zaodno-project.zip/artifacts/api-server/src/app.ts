import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

function isAllowedOrigin(origin: string | undefined): boolean {
  if (!origin) return true;
  try {
    const hostname = new URL(origin).hostname;
    const configuredDomains = [
      process.env["REPLIT_DEV_DOMAIN"],
      ...(process.env["REPLIT_DOMAINS"]?.split(",") ?? []),
    ]
      .map((domain) => domain?.trim())
      .filter((domain): domain is string => Boolean(domain));
    return (
      configuredDomains.includes(hostname) ||
      hostname.endsWith(".expo.sisko.replit.dev")
    );
  } catch {
    return false;
  }
}

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(
  cors({
    origin(origin, callback) {
      callback(null, isAllowedOrigin(origin));
    },
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
