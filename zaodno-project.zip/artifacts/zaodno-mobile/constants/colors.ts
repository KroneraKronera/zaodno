/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#1c1c22',
    tint: '#5d58c9',

    // Core surfaces
    background: '#f7f6f2',
    foreground: '#1c1c22',

    // Cards / elevated surfaces
    card: '#fffdfa',
    cardForeground: '#1c1c22',

    // Primary action color (buttons, links, active states)
    primary: '#5d58c9',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#efedff',
    secondaryForeground: '#4a45a7',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#f0eee8',
    mutedForeground: '#7e7a88',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#ffe8de',
    accentForeground: '#a14f39',

    // Destructive actions (delete, error states)
    destructive: '#d95d5d',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#ebe8e1',
    input: '#e3e0d8',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 22,
};

export default colors;
