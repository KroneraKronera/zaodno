const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const projectRoot = path.resolve(__dirname, '..');
const outputRoot = path.join(projectRoot, 'static-build');
const iconSource = path.join(projectRoot, 'assets', 'images', 'icon.png');

function stripProtocol(value) {
  const normalized = /^https?:\/\//i.test(value)
    ? value
    : `https://${value}`;
  return new URL(normalized).host;
}

function getPublicDomain() {
  const value =
    process.env.REPLIT_INTERNAL_APP_DOMAIN ||
    process.env.REPLIT_DEV_DOMAIN ||
    process.env.EXPO_PUBLIC_DOMAIN;

  if (!value) {
    throw new Error(
      'No public domain found. Set REPLIT_INTERNAL_APP_DOMAIN, REPLIT_DEV_DOMAIN, or EXPO_PUBLIC_DOMAIN.',
    );
  }

  return stripProtocol(value);
}

function runExpoExport(publicDomain) {
  console.log('Building Expo web application...');

  const result = spawnSync(
    'pnpm',
    [
      'exec',
      'expo',
      'export',
      '--platform',
      'web',
      '--output-dir',
      outputRoot,
      '--clear',
    ],
    {
      cwd: projectRoot,
      env: {
        ...process.env,
        EXPO_PUBLIC_DOMAIN: publicDomain,
      },
      stdio: 'inherit',
    },
  );

  if (result.error) {
    throw result.error;
  }

  if (result.status !== 0) {
    throw new Error(`Expo web export failed with exit code ${result.status}`);
  }
}

function walkFiles(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolutePath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      return walkFiles(absolutePath);
    }
    return [absolutePath];
  });
}

function toPublicPath(filePath) {
  const relativePath = path.relative(outputRoot, filePath).split(path.sep).join('/');
  return `/${relativePath}`;
}

function writeManifest() {
  const manifest = {
    id: '/',
    name: 'Заодно — семейный помощник',
    short_name: 'Заодно',
    description:
      'Семейный помощник для покупок, дел, событий и поручений.',
    lang: 'ru',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait-primary',
    background_color: '#f7f6f2',
    theme_color: '#f7f6f2',
    icons: [
      {
        src: '/pwa-icon-192.png',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'any',
      },
      {
        src: '/pwa-icon-512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any maskable',
      },
    ],
  };

  fs.writeFileSync(
    path.join(outputRoot, 'manifest.webmanifest'),
    `${JSON.stringify(manifest, null, 2)}\n`,
  );
}

function enhanceIndexHtml() {
  const indexPath = path.join(outputRoot, 'index.html');
  let html = fs.readFileSync(indexPath, 'utf8');

  html = html
    .replace('<html lang="en">', '<html lang="ru">')
    .replace(
      '<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />',
      [
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />',
        '    <meta name="theme-color" content="#f7f6f2" />',
        '    <meta name="description" content="Заодно — семейный помощник для покупок, дел, событий и поручений." />',
        '    <meta name="apple-mobile-web-app-capable" content="yes" />',
        '    <meta name="apple-mobile-web-app-status-bar-style" content="default" />',
        '    <meta name="apple-mobile-web-app-title" content="Заодно" />',
        '    <link rel="manifest" href="/manifest.webmanifest" />',
        '    <link rel="apple-touch-icon" href="/pwa-icon-192.png" />',
      ].join('\n'),
    )
    .replace(
      '</body>',
      [
        '  <script>',
        "    if ('serviceWorker' in navigator) {",
        "      window.addEventListener('load', function () {",
        "        navigator.serviceWorker.register('/sw.js').catch(function (error) {",
        "          console.warn('Service worker registration failed:', error);",
        '        });',
        '      });',
        '    }',
        '  </script>',
        '</body>',
      ].join('\n'),
    );

  fs.writeFileSync(indexPath, html);
}

function writeServiceWorker() {
  const filesToCache = walkFiles(outputRoot)
    .map(toPublicPath)
    .filter(
      (filePath) =>
        filePath !== '/metadata.json' &&
        filePath !== '/sw.js' &&
        !filePath.endsWith('.map'),
    )
    .sort();

  const serviceWorker = `const CACHE_NAME = 'zaodno-${Date.now()}';
const APP_SHELL = ${JSON.stringify(filesToCache, null, 2)};

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)),
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key.startsWith('zaodno-') && key !== CACHE_NAME)
            .map((key) => caches.delete(key)),
        ),
      ),
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  if (
    event.request.method !== 'GET' ||
    url.origin !== self.location.origin ||
    url.pathname.startsWith('/api/')
  ) {
    return;
  }

  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('/index.html')),
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(
      (cached) =>
        cached ||
        fetch(event.request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        }),
    ),
  );
});
`;

  fs.writeFileSync(path.join(outputRoot, 'sw.js'), serviceWorker);
}

function copyPwaIcons() {
  const icons = [
    ['pwa-icon-192.png', path.join(projectRoot, 'assets', 'images', 'pwa-icon-192.png')],
    ['pwa-icon-512.png', path.join(projectRoot, 'assets', 'images', 'pwa-icon-512.png')],
  ];

  for (const [outputName, sourcePath] of icons) {
    fs.copyFileSync(
      fs.existsSync(sourcePath) ? sourcePath : iconSource,
      path.join(outputRoot, outputName),
    );
  }
}

function main() {
  const publicDomain = getPublicDomain();
  runExpoExport(publicDomain);
  copyPwaIcons();
  writeManifest();
  enhanceIndexHtml();
  writeServiceWorker();
  console.log(`Web PWA build complete for https://${publicDomain}`);
}

try {
  main();
} catch (error) {
  console.error(`Build failed: ${error.message}`);
  process.exit(1);
}