export type Intent = 'shopping' | 'task' | 'event' | 'assignment' | 'note';

export interface Interpretation {
  intent: Intent;
  title: string;
  items: string[];
  date?: string;
  time?: string;
  assignee?: string | null;
  needsClarification: boolean;
  clarificationQuestion?: string;
  clarificationOptions: string[];
  confirmationText: string;
}

function localDate(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function dateFromText(text: string): string | undefined {
  const now = new Date();
  const normalized = text.toLocaleLowerCase().replaceAll('ё', 'е');
  if (normalized.includes('сегодня')) return localDate(now);
  if (normalized.includes('завтра')) {
    now.setDate(now.getDate() + 1);
    return localDate(now);
  }
  return undefined;
}

function timeFromText(text: string): string | undefined {
  const match = text.match(/(?:в|к|до)\s*(\d{1,2})(?::(\d{2}))?/i);
  if (!match) return undefined;
  const hour = Number(match[1]);
  const minute = Number(match[2] ?? 0);
  return hour >= 0 && hour < 24 && minute >= 0 && minute < 60
    ? `${`${hour}`.padStart(2, '0')}:${`${minute}`.padStart(2, '0')}`
    : undefined;
}

export function interpretText(text: string, family: string[]): Interpretation {
  const cleaned = text.trim().replace(/\s+/g, ' ');
  const normalized = cleaned.toLocaleLowerCase().replaceAll('ё', 'е');
  const date = dateFromText(normalized);
  const time = timeFromText(normalized);
  const eligibleFamily = family.filter(
    (member) => member.toLocaleLowerCase() !== 'маша',
  );
  const assignee =
    eligibleFamily.find((member) =>
      normalized.includes(member.toLocaleLowerCase().replaceAll('ё', 'е')),
    ) ?? null;

  const items = extractShoppingItems(cleaned);

  if (
    items.length > 0 &&
    ['нет', 'законч', 'куп', 'нужно', 'надо'].some((word) =>
      normalized.includes(word),
    )
  ) {
    return {
      intent: 'shopping',
      title: 'Покупки',
      items,
      date,
      time,
      assignee: null,
      needsClarification: false,
      clarificationOptions: [],
      confirmationText: 'Добавила в покупки',
    };
  }

  if (
    normalized.includes('кто') &&
    (normalized.includes('забрать') || normalized.includes('заберет'))
  ) {
    return {
      intent: 'task',
      title: 'Забрать ребёнка',
      date,
      time,
      assignee: null,
      items: [],
      needsClarification: true,
      clarificationQuestion: 'Кто заберёт?',
      clarificationOptions: [...eligibleFamily, 'Пока неизвестно'],
      confirmationText: 'Нужно уточнить исполнителя',
    };
  }

  if (
    normalized.startsWith('пусть ') ||
    normalized.includes('поручи') ||
    normalized.includes('передай') ||
    (!assignee &&
      /\b(?:надо|нужно|необходимо)\b(?:\s+\S+){0,3}\s+\b(?:забрать|отвезти|отнести|позвонить|вызвать|оплатить|записать|сходить|помыть|убрать)\b/iu.test(
        normalized,
      )) ||
    (assignee !== null &&
      ['купит', 'заберет', 'заберет', 'отвезет', 'позвонит', 'сделает'].some(
        (word) => normalized.includes(word),
      ))
  ) {
    return {
      intent: 'assignment',
      title: cleaned,
      date,
      time,
      assignee,
      items: [],
      needsClarification: assignee === null,
      clarificationQuestion: assignee ? undefined : 'Кому поручить?',
      clarificationOptions: assignee ? [] : eligibleFamily,
      confirmationText: assignee ? `Передала ${assignee}` : 'Нужно выбрать исполнителя',
    };
  }

  if (
    ['день рождения', 'утренник', 'встреч', 'трениров', 'врач', 'стоматолог', 'театр', 'концерт'].some(
      (word) => normalized.includes(word),
    ) &&
    (date || time || normalized.includes('пятниц') || normalized.includes('суббот'))
  ) {
    return {
      intent: 'event',
      title: cleaned,
      date,
      time,
      assignee: null,
      items: [],
      needsClarification: false,
      clarificationOptions: [],
      confirmationText: 'Добавила в план',
    };
  }

  if (
    ['надо', 'нужно', 'забрать', 'отвез', 'позвон', 'вызвать', 'оплат', 'записать'].some(
      (word) => normalized.includes(word),
    )
  ) {
    return {
      intent: 'task',
      title: cleaned,
      date,
      time,
      assignee,
      items: [],
      needsClarification: false,
      clarificationOptions: [],
      confirmationText: 'Добавила в дела',
    };
  }

  return {
    intent: 'note',
    title: cleaned,
    items: [],
    assignee: null,
    needsClarification: false,
    clarificationOptions: [],
    confirmationText: 'Запомнила',
  };
}

function normalizeShoppingItem(item: string): string {
  const normalized = item
    .trim()
    .replace(/[.!?:;,"«»]/g, '')
    .replace(/\s+/g, ' ')
    .replace(/^(еще|ещё|также|и)\s+/i, '')
    .replace(/\s+(сегодня|завтра|срочно|пожалуйста)$/i, '');
  const forms: Record<string, string> = {
    молока: 'молоко',
    сливок: 'сливки',
    масла: 'масло',
    яиц: 'яйца',
    огурцов: 'огурцы',
    помидоров: 'помидоры',
    бананов: 'бананы',
    яблок: 'яблоки',
    хлеба: 'хлеб',
    сыра: 'сыр',
    кефира: 'кефир',
    воды: 'вода',
    чая: 'чай',
    корма: 'корм',
    батареек: 'батарейки',
    бумаги: 'туалетная бумага',
  };
  return forms[normalized.toLocaleLowerCase().replaceAll('ё', 'е')] ?? normalized;
}

function extractShoppingItems(text: string): string[] {
  const normalized = text.toLocaleLowerCase().replaceAll('ё', 'е').replace(/\s+/g, ' ');
  const patterns = [
    /(?:^|[.!?]\s*)(?:у нас\s+)?нет\s+(.+)/,
    /^(.+?)\s+нет(?:[.!?]|$)/,
    /(?:^|[.!?]\s*)законч(?:ился|илась|илось|ились)\s+(.+)/,
    /^(.+?)\s+законч(?:ился|илась|илось|ились)(?:[.!?]|$)/,
    /^(?:надо|нужно)?\s*(?:купить|купи|докупить)\s+(.+)/,
  ];
  let captured: string | undefined;
  for (const pattern of patterns) {
    const match = normalized.match(pattern);
    if (match) {
      captured = match[1];
      break;
    }
  }
  if (!captured) {
    const knownItems: Record<string, string> = {
      молоко: 'молоко',
      молока: 'молоко',
      яйца: 'яйца',
      яиц: 'яйца',
      хлеб: 'хлеб',
      сыр: 'сыр',
    };
    return Object.entries(knownItems)
      .filter(([word]) => normalized.includes(word))
      .map(([, item]) => item)
      .filter((item, index, all) => all.indexOf(item) === index);
  }

  const list = captured
    .split(/\s+(?:а\s+)?(?:потом|затем|и\s+надо|и\s+нужно|не\s+забудь)\b/)[0]
    .replace(/\b(?:нужно|надо)\s+(?:сегодня|завтра)\b.*$/i, '')
    .replace(/\b(?:сегодня|завтра|пожалуйста)\b\s*$/i, '');
  const items = list
    .split(/\s*,\s*|\s*;\s*|\s+и\s+/)
    .map(normalizeShoppingItem)
    .filter((item) => item.length > 0 && item.length <= 80)
    .filter((item) => !/\b(?:забрать|отвезти|позвонить|оплатить|вызвать|записать)\b/.test(item));
  return items.filter((item, index) => items.indexOf(item) === index);
}