import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Platform } from 'react-native';

export type TaskKind = 'task' | 'event' | 'assignment';
export type TaskStatus = 'open' | 'needs-assignee' | 'done';

export interface FamilyTask {
  id: string;
  title: string;
  date?: string;
  time?: string;
  assignee?: string | null;
  kind: TaskKind;
  status: TaskStatus;
}

export interface ShoppingItem {
  id: string;
  title: string;
  done: boolean;
}

interface ZaodnoState {
  family: string[];
  tasks: FamilyTask[];
  shopping: ShoppingItem[];
}

export interface ZaodnoSnapshot {
  tasks: FamilyTask[];
  shopping: ShoppingItem[];
}

export interface CaptureAction {
  intent: 'shopping' | 'task' | 'event' | 'assignment' | 'note' | 'unknown';
  title: string;
  items: string[];
  date?: string | null;
  time?: string | null;
  assignee?: string | null;
  needsClarification: boolean;
}

interface ZaodnoContextValue extends ZaodnoState {
  isHydrated: boolean;
  addTask: (task: Omit<FamilyTask, 'id' | 'status'> & { status?: TaskStatus }) => void;
  applyCaptureActions: (
    actions: CaptureAction[],
  ) => Promise<{ createdTaskIds: string[]; needsAssigneeTaskIds: string[] }>;
  updateTaskAssignee: (id: string, assignee: string) => Promise<void>;
  toggleTask: (id: string) => void;
  addShoppingItems: (items: string[]) => void;
  toggleShopping: (id: string) => void;
  removeShopping: (id: string) => void;
  clearCompletedShopping: () => void;
  addFamilyMember: (name: string) => void;
  removeFamilyMember: (name: string) => void;
  restoreSnapshot: (snapshot: ZaodnoSnapshot) => void;
}

const STORAGE_KEY = '@zaodno/state';
let persistenceQueue: Promise<void> = Promise.resolve();

function persistState(state: ZaodnoState): Promise<void> {
  const serialized = JSON.stringify(state);
  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    window.localStorage.setItem(STORAGE_KEY, serialized);
    window.sessionStorage.setItem(STORAGE_KEY, serialized);
  }
  persistenceQueue = persistenceQueue
    .catch(() => undefined)
    .then(() => AsyncStorage.setItem(STORAGE_KEY, serialized));
  return persistenceQueue;
}

function localDate(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function id(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeShoppingTitle(value: string): string {
  return value
    .trim()
    .replace(/^(?:item|название|товар)\s*[:=]\s*/iu, '')
    .replace(/^['"`]+|['"`]+$/g, '')
    .trim();
}

const today = localDate(new Date());
const INITIAL_STATE: ZaodnoState = {
  family: ['Яна', 'Саша', 'Маша', 'Бабушка'],
  tasks: [
    {
      id: 'starter-1',
      title: 'Отвести ребёнка в сад',
      date: today,
      time: '08:30',
      assignee: 'Саша',
      kind: 'assignment',
      status: 'open',
    },
    {
      id: 'starter-2',
      title: 'Забрать ребёнка',
      date: today,
      time: '17:00',
      assignee: 'Яна',
      kind: 'assignment',
      status: 'open',
    },
  ],
  shopping: [],
};

const ZaodnoContext = createContext<ZaodnoContextValue | null>(null);

function normalizeSavedTask(value: unknown): FamilyTask | null {
  if (!value || typeof value !== 'object') return null;
  const task = value as Partial<FamilyTask> & { done?: boolean };
  if (
    typeof task.id !== 'string' ||
    typeof task.title !== 'string' ||
    !task.kind ||
    !['task', 'event', 'assignment'].includes(task.kind)
  ) {
    return null;
  }
  const status: TaskStatus =
    task.status === 'open' ||
    task.status === 'needs-assignee' ||
    task.status === 'done'
      ? task.status
      : task.done
        ? 'done'
        : 'open';
  return {
    id: task.id,
    title: task.title,
    date: task.date,
    time: task.time,
    assignee: task.assignee,
    kind: task.kind,
    status,
  };
}

function withShoppingItems(
  current: ShoppingItem[],
  items: string[],
): ShoppingItem[] {
  const existing = new Set(
    current.map((item) => normalizeShoppingTitle(item.title).toLocaleLowerCase()),
  );
  const additions = items.reduce<ShoppingItem[]>((result, item) => {
    const title = normalizeShoppingTitle(item);
    const key = title.toLocaleLowerCase();
    if (!title || existing.has(key)) return result;
    existing.add(key);
    result.push({ id: id(), title, done: false });
    return result;
  }, []);
  return [...additions, ...current];
}

function normalizeSavedShoppingItem(value: unknown): ShoppingItem | null {
  if (!value || typeof value !== 'object') return null;
  const item = value as Partial<ShoppingItem>;
  const title =
    typeof item.title === 'string' ? normalizeShoppingTitle(item.title) : '';
  if (
    typeof item.id !== 'string' ||
    !title ||
    /^item\s*[:=]\s*['"`]?\s*['"`]?$/i.test(title)
  ) {
    return null;
  }
  return {
    id: item.id,
    title,
    done: Boolean(item.done),
  };
}

function normalizeSavedShoppingItems(values: unknown[]): ShoppingItem[] {
  const seen = new Set<string>();
  return values
    .map(normalizeSavedShoppingItem)
    .filter((item): item is ShoppingItem => {
      if (!item) return false;
      const key = item.title.toLocaleLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

export function ZaodnoProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<ZaodnoState>(INITIAL_STATE);
  const [isHydrated, setIsHydrated] = useState(false);
  const stateRef = useRef<ZaodnoState>(INITIAL_STATE);
  const mutationQueueRef = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    Promise.resolve(
      Platform.OS === 'web' && typeof window !== 'undefined'
        ? window.localStorage.getItem(STORAGE_KEY) ??
            window.sessionStorage.getItem(STORAGE_KEY)
        : null,
    )
      .then((webValue) => webValue ?? AsyncStorage.getItem(STORAGE_KEY))
      .then((raw) => {
        if (raw) {
          const saved = JSON.parse(raw) as Partial<ZaodnoState>;
          const hydratedState: ZaodnoState = {
            family: Array.isArray(saved.family) ? saved.family : INITIAL_STATE.family,
            tasks: Array.isArray(saved.tasks)
              ? saved.tasks.map(normalizeSavedTask).filter((task): task is FamilyTask => Boolean(task))
              : INITIAL_STATE.tasks,
            shopping: Array.isArray(saved.shopping)
              ? normalizeSavedShoppingItems(saved.shopping)
              : INITIAL_STATE.shopping,
          };
          stateRef.current = hydratedState;
          setState(hydratedState);
        }
      })
      .catch(() => undefined)
      .finally(() => setIsHydrated(true));
  }, []);

  const updateState = (updater: (current: ZaodnoState) => ZaodnoState) => {
    const next = updater(stateRef.current);
    stateRef.current = next;
    setState(next);
    void persistState(next).catch(() => undefined);
  };

  const commitMutation = <T,>(
    updater: (current: ZaodnoState) => { state: ZaodnoState; result: T },
  ): Promise<T> => {
    const operation = mutationQueueRef.current
      .catch(() => undefined)
      .then(async () => {
        const transition = updater(stateRef.current);
        stateRef.current = transition.state;
        setState(transition.state);
        await persistState(transition.state);
        return transition.result;
      });
    mutationQueueRef.current = operation.then(
      () => undefined,
      () => undefined,
    );
    return operation;
  };

  const value = useMemo<ZaodnoContextValue>(
    () => ({
      ...state,
      isHydrated,
      addTask: (task) =>
        updateState((current) => ({
          ...current,
          tasks: [
            { ...task, id: id(), status: task.status ?? 'open' },
            ...current.tasks,
          ],
        })),
      applyCaptureActions: async (actions) => {
        return commitMutation((current) => {
          const createdTasks: FamilyTask[] = actions
            .filter(
              (action) =>
                action.intent === 'task' ||
                action.intent === 'event' ||
                action.intent === 'assignment',
            )
            .map((action) => ({
              id: id(),
              title: action.title,
              date: action.date ?? undefined,
              time: action.time ?? undefined,
              assignee: action.assignee ?? undefined,
              kind:
                action.intent === 'event'
                  ? 'event'
                  : action.intent === 'assignment'
                    ? 'assignment'
                    : 'task',
              status:
                action.needsClarification && !action.assignee
                  ? 'needs-assignee'
                  : 'open',
            }));
          const shoppingItems = actions.flatMap((action) =>
            action.intent === 'shopping' ? action.items : [],
          );
          return {
            state: {
              ...current,
              tasks: [...createdTasks, ...current.tasks],
              shopping: withShoppingItems(current.shopping, shoppingItems),
            },
            result: {
              createdTaskIds: createdTasks.map((task) => task.id),
              needsAssigneeTaskIds: createdTasks
                .filter((task) => task.status === 'needs-assignee')
                .map((task) => task.id),
            },
          };
        });
      },
      updateTaskAssignee: async (taskId, assignee) => {
        await commitMutation((current) => ({
          state: {
            ...current,
            tasks: current.tasks.map((task) =>
              task.id === taskId
                ? { ...task, assignee, status: 'open' }
                : task,
            ),
          },
          result: undefined,
        }));
      },
      toggleTask: (taskId) =>
        updateState((current) => ({
          ...current,
          tasks: current.tasks.map((task) =>
            task.id === taskId
              ? {
                  ...task,
                  status: task.status === 'done' ? 'open' : 'done',
                }
              : task,
          ),
        })),
      addShoppingItems: (items) =>
        updateState((current) => ({
          ...current,
          shopping: withShoppingItems(current.shopping, items),
        })),
      toggleShopping: (shoppingId) =>
        updateState((current) => ({
          ...current,
          shopping: current.shopping.map((item) =>
            item.id === shoppingId ? { ...item, done: !item.done } : item,
          ),
        })),
      removeShopping: (shoppingId) =>
        updateState((current) => ({
          ...current,
          shopping: current.shopping.filter((item) => item.id !== shoppingId),
        })),
      clearCompletedShopping: () =>
        updateState((current) => ({
          ...current,
          shopping: current.shopping.filter((item) => !item.done),
        })),
      addFamilyMember: (name) =>
        updateState((current) => {
          const normalized = name.trim();
          if (
            !normalized ||
            current.family.some(
              (member) => member.toLocaleLowerCase() === normalized.toLocaleLowerCase(),
            )
          ) {
            return current;
          }
          return { ...current, family: [...current.family, normalized] };
        }),
      removeFamilyMember: (name) =>
        updateState((current) => ({
          ...current,
          family:
            current.family.length > 1
              ? current.family.filter((member) => member !== name)
              : current.family,
        })),
      restoreSnapshot: (snapshot) =>
        updateState((current) => ({
          ...current,
          tasks: snapshot.tasks,
          shopping: snapshot.shopping,
        })),
    }),
    [isHydrated, state],
  );

  return <ZaodnoContext.Provider value={value}>{children}</ZaodnoContext.Provider>;
}

export function useZaodno() {
  const context = useContext(ZaodnoContext);
  if (!context) {
    throw new Error('useZaodno must be used within ZaodnoProvider');
  }
  return context;
}