/**
 * Production server for the exported Expo web application.
 *
 * The Replit router sends /api to the API artifact. This service owns the
 * browser application at / and provides an SPA fallback for Expo Router.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const STATIC_ROOT = path.resolve(__dirname, '..', 'static-build');
const INDEX_PATH = path.join(STATIC_ROOT, 'index.html');
const basePath = (process.env.BASE_PATH || '/').replace(/\/+$/, '');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.map': 'application/json',
};

function send(res, statusCode, body, headers = {}) {
  res.writeHead(statusCode, {
    'x-content-type-options': 'nosniff',
    ...headers,
  });
  res.end(body);
}

function sendFile(filePath, res) {
  const extension = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[extension] || 'application/octet-stream';
  const fileName = path.basename(filePath);
  const cacheControl =
    fileName === 'index.html' ||
    fileName === 'sw.js' ||
    fileName === 'manifest.webmanifest'
      ? 'no-cache'
      : 'public, max-age=31536000, immutable';

  send(res, 200, fs.readFileSync(filePath), {
    'content-type': contentType,
    'cache-control': cacheControl,
  });
}

function resolveStaticFile(pathname) {
  const relativePath = pathname.replace(/^\/+/, '');
  const filePath = path.resolve(STATIC_ROOT, relativePath);

  if (
    filePath !== STATIC_ROOT &&
    !filePath.startsWith(`${STATIC_ROOT}${path.sep}`)
  ) {
    return null;
  }

  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    return null;
  }

  return filePath;
}

if (!fs.existsSync(INDEX_PATH)) {
  console.error(
    `Missing ${INDEX_PATH}. Run the production build before starting the server.`,
  );
  process.exit(1);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    send(res, 405, 'Method Not Allowed', { allow: 'GET, HEAD' });
    return;
  }

  let url;
  try {
    url = new URL(req.url || '/', 'http://localhost');
  } catch {
    send(res, 400, 'Bad Request');
    return;
  }

  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    send(res, 400, 'Bad Request');
    return;
  }

  if (basePath && pathname.startsWith(basePath)) {
    pathname = pathname.slice(basePath.length) || '/';
  }

  if (pathname === '/status') {
    send(res, 200, JSON.stringify({ status: 'ok' }), {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    });
    return;
  }

  const staticFile = resolveStaticFile(pathname);
  if (staticFile) {
    sendFile(staticFile, res);
    return;
  }

  if (path.extname(pathname)) {
    send(res, 404, 'Not Found');
    return;
  }

  sendFile(INDEX_PATH, res);
});

const port = Number.parseInt(process.env.PORT || '3000', 10);
server.listen(port, '0.0.0.0', () => {
  console.log(`Serving Заодно web PWA on port ${port}`);
});