import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { request as httpsRequest } from "node:https";
import {
  InterpretIntentResponse,
  type InterpretedAction,
  type Interpretation,
} from "@workspace/api-zod";

const OAUTH_URL = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
const COMPLETIONS_URL = "https://api.giga.chat/v1/chat/completions";
const DEFAULT_SCOPE = "GIGACHAT_API_PERS";
const DEFAULT_MODEL = "GigaChat-2-Max";
const GIGACHAT_CA = readFileSync(
  new URL("./certs/russian_trusted_root_ca.pem", import.meta.url),
  "utf8",
);

type GigaChatStage = "oauth" | "completion" | "structured_output";

export class GigaChatRequestError extends Error {
  readonly stage: GigaChatStage;
  readonly status: number | null;
  readonly validationFields: string[];

  constructor(
    stage: GigaChatStage,
    message: string,
    status: number | null = null,
    validationFields: string[] = [],
  ) {
    super(message);
    this.name = "GigaChatRequestError";
    this.stage = stage;
    this.status = status;
    this.validationFields = validationFields;
  }
}

type TokenCache = {
  token: string | null;
  expiresAt: number;
};

const tokenCache: TokenCache = {
  token: null,
  expiresAt: 0,
};

const structuredActionSchema = {
  type: "object",
  properties: {
    intent: {
      type: "string",
      enum: ["shopping", "task", "event", "assignment", "note", "unknown"],
    },
    title: { type: "string" },
    items: { type: "array", items: { type: "string" } },
    date: {
      type: ["string", "null"],
      description: "YYYY-MM-DD or null",
    },
    time: {
      type: ["string", "null"],
      description: "HH:MM or null",
    },
    assignee: { type: ["string", "null"] },
    confidence: { type: "number", minimum: 0, maximum: 1 },
    needs_clarification: { type: "boolean" },
    clarification_question: { type: ["string", "null"] },
    clarification_options: { type: "array", items: { type: "string" } },
    confirmation_text: { type: "string" },
  },
  required: [
    "intent",
    "title",
    "items",
    "date",
    "time",
    "assignee",
    "confidence",
    "needs_clarification",
    "clarification_question",
    "clarification_options",
    "confirmation_text",
  ],
  additionalProperties: false,
} as const;

const structuredInterpretationSchema = {
  type: "object",
  properties: {
    actions: {
      type: "array",
      minItems: 1,
      items: structuredActionSchema,
    },
  },
  required: ["actions"],
  additionalProperties: false,
} as const;

function getAuthKey(): string | null {
  const value = process.env["GIGACHAT_AUTH_KEY"]?.trim();
  return value || null;
}

export function getGigaChatConfig() {
  return {
    configured: Boolean(getAuthKey()),
    model: process.env["GIGACHAT_MODEL"]?.trim() || DEFAULT_MODEL,
    scope: process.env["GIGACHAT_SCOPE"]?.trim() || DEFAULT_SCOPE,
  };
}

function withBasicPrefix(authKey: string): string {
  return authKey.toLowerCase().startsWith("basic ")
    ? authKey
    : `Basic ${authKey}`;
}

function parseExpiry(value: unknown, now: number): number {
  const numeric = typeof value === "string" ? Number(value) : value;
  if (typeof numeric !== "number" || !Number.isFinite(numeric) || numeric <= 0) {
    return now + 1_700_000;
  }
  return numeric > 10_000_000_000 ? numeric : numeric * 1_000;
}

function postWithPinnedCa(
  stage: GigaChatStage,
  url: string,
  headers: Record<string, string>,
  body: string,
  timeoutMs: number,
): Promise<{ ok: boolean; status: number; body: unknown }> {
  return new Promise((resolve, reject) => {
    const request = httpsRequest(
      url,
      {
        method: "POST",
        ca: GIGACHAT_CA,
        minVersion: "TLSv1.2",
        headers: {
          ...headers,
          "Content-Length": Buffer.byteLength(body).toString(),
        },
      },
      (response) => {
        const chunks: Buffer[] = [];
        response.on("data", (chunk: Buffer) => chunks.push(chunk));
        response.on("end", () => {
          const status = response.statusCode ?? 0;
          const raw = Buffer.concat(chunks).toString("utf8");
          let parsed: unknown = null;
          if (raw) {
            try {
              parsed = JSON.parse(raw);
            } catch {
              reject(
                new GigaChatRequestError(
                  stage,
                  "GigaChat response was not valid JSON",
                  status || null,
                ),
              );
              return;
            }
          }
          resolve({
            ok: status >= 200 && status < 300,
            status,
            body: parsed,
          });
        });
      },
    );

    request.setTimeout(timeoutMs, () => {
      request.destroy(new Error(`Request timed out after ${timeoutMs}ms`));
    });
    request.on("error", (error) => {
      reject(new GigaChatRequestError(stage, error.message));
    });
    request.end(body);
  });
}

export async function getAccessToken(): Promise<string> {
  const authKey = getAuthKey();
  if (!authKey) {
    throw new GigaChatRequestError("oauth", "GigaChat is not configured");
  }

  const now = Date.now();
  if (tokenCache.token && tokenCache.expiresAt - now > 60_000) {
    return tokenCache.token;
  }

  const response = await postWithPinnedCa(
    "oauth",
    OAUTH_URL,
    {
        Authorization: withBasicPrefix(authKey),
        RqUID: randomUUID(),
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    },
    new URLSearchParams({ scope: getGigaChatConfig().scope }).toString(),
    20_000,
  );

  if (!response.ok) {
    throw new GigaChatRequestError(
      "oauth",
      `OAuth request failed with HTTP ${response.status}`,
      response.status,
    );
  }

  const body = response.body as {
    access_token?: unknown;
    expires_at?: unknown;
  };
  if (typeof body.access_token !== "string" || !body.access_token) {
    throw new GigaChatRequestError(
      "oauth",
      "OAuth response did not contain an access token",
      response.status || null,
    );
  }

  tokenCache.token = body.access_token;
  tokenCache.expiresAt = parseExpiry(body.expires_at, now);
  return tokenCache.token;
}

function buildSystemPrompt(
  familyMembers: string[],
  nowIso: string,
): string {
  const members = familyMembers.join(", ") || "не указаны";
  return `Ты интерпретатор бытовых запросов семейного приложения «Заодно».
Текущее локальное время: ${nowIso}. Участники семьи: ${members}.
Цель: минимизировать вопросы. Простые и безопасные запросы выполняются сразу.
Верни объект с массивом actions. Одна фраза может содержать несколько независимых действий — выдели каждое отдельным элементом actions.
Перечисление объектов одного действия не разделяй: «купить молоко, яйца и масло» — это один shopping action с тремя items.
Если после перечисления начинается другой глагол-действие, создай новый action: «купить хлеб и позвонить маме» — shopping и task.
Неопределенность одного action не должна блокировать остальные actions. Для поручения без названного исполнителя поставь assignee=null и needs_clarification=true.
Не требуй дату, если пользователь ее не назвал и она не нужна для смысла.
Если пользователь перечисляет продукты с фразами «нет/закончились/купить» — intent=shopping, items=список ВСЕХ явно перечисленных товаров. Никогда не пропускай второй, третий и последующие товары.
Если явно просит другого члена семьи сделать действие — intent=assignment и assignee=имя.
Если есть конкретное время/дата и это встреча/утренник/врач/секция — intent=event.
Если действие надо сделать, но это не событие и не покупка — intent=task.
needs_clarification=true только если без уточнения возможна значимая ошибка.
confirmation_text — короткая русская фраза в стиле «Добавила в покупки», «Запланировала», «Передала Саше».
Не добавляй персональные данные, которых нет во входе.`;
}

function readCompletionContent(body: unknown): string {
  if (!body || typeof body !== "object") {
    throw new GigaChatRequestError(
      "structured_output",
      "Completion response is not an object",
    );
  }
  const choices = (body as { choices?: unknown }).choices;
  if (!Array.isArray(choices) || choices.length === 0) {
    throw new GigaChatRequestError(
      "structured_output",
      "Completion response did not contain choices",
    );
  }
  const content = (choices[0] as { message?: { content?: unknown } })?.message
    ?.content;
  if (typeof content === "object" && content !== null) {
    return JSON.stringify(content);
  }
  if (typeof content !== "string" || !content.trim()) {
    throw new GigaChatRequestError(
      "structured_output",
      "Completion response did not contain message content",
    );
  }
  return content;
}

function parseStructuredContent(content: string): unknown {
  const trimmed = content.trim();
  const withoutFence = trimmed
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  const firstBrace = withoutFence.indexOf("{");
  const firstBracket = withoutFence.indexOf("[");
  const lastBrace = withoutFence.lastIndexOf("}");
  const lastBracket = withoutFence.lastIndexOf("]");
  const usesArray =
    firstBracket >= 0 && (firstBrace < 0 || firstBracket < firstBrace);
  const firstStructured = usesArray ? firstBracket : firstBrace;
  const lastStructured = usesArray ? lastBracket : lastBrace;
  const candidate =
    firstStructured >= 0 && lastStructured > firstStructured
      ? withoutFence.slice(firstStructured, lastStructured + 1)
      : withoutFence;
  let parsed: unknown;
  try {
    parsed = JSON.parse(candidate);
  } catch {
    const knownKeys = new Set([
      "actions",
      "intent",
      "title",
      "items",
      "date",
      "time",
      "assignee",
      "confidence",
      "needs_clarification",
      "needsClarification",
      "clarification_question",
      "clarificationQuestion",
      "clarification_options",
      "clarificationOptions",
      "confirmation_text",
      "confirmationText",
    ]);
    const repaired = candidate
      .split(/\r?\n/)
      .map((line) => {
        const keyMatch = line.match(/"([^"]+)"\s*:/);
        if (keyMatch && knownKeys.has(keyMatch[1])) {
          const indentation = line.match(/^\s*/)?.[0] ?? "";
          return `${indentation}${line.slice(line.indexOf(`"${keyMatch[1]}"`))}`;
        }
        const trimmed = line.trim();
        if (
          !trimmed ||
          /^[{}\[\]][,]?$/.test(trimmed) ||
          /^"(?:[^"\\]|\\.)*"[,]?$/.test(trimmed)
        ) {
          return line;
        }
        return "";
      })
      .filter(Boolean)
      .join("\n");
    parsed = JSON.parse(repaired);
  }
  return typeof parsed === "string" ? JSON.parse(parsed) : parsed;
}

function validationIssueFields(error: unknown): string[] {
  if (
    !error ||
    typeof error !== "object" ||
    !("issues" in error) ||
    !Array.isArray(error.issues)
  ) {
    return [];
  }
  return error.issues
    .map((issue: unknown) => {
      if (
        !issue ||
        typeof issue !== "object" ||
        !("path" in issue) ||
        !Array.isArray(issue.path)
      ) {
        return null;
      }
      return issue.path.map(String).join(".");
    })
    .filter((field: string | null): field is string => Boolean(field));
}

function nullableString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed || null;
}

function normalizeTime(value: unknown, sourceText: string): string | null {
  const candidate = nullableString(value);
  const fromValue = candidate?.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
  const fromText = sourceText.match(/\b(?:в\s*)?([01]?\d|2[0-3]):([0-5]\d)\b/);
  const match = fromValue ?? fromText;
  return match ? `${match[1].padStart(2, "0")}:${match[2]}` : null;
}

function toLocalDate(date: Date): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dateFromRelativeText(text: string, nowIso: string): string | null {
  const lower = text.toLowerCase().replaceAll("ё", "е");
  const date = new Date(nowIso);
  if (Number.isNaN(date.getTime())) return null;
  if (lower.includes("сегодня")) return toLocalDate(date);
  if (lower.includes("завтра")) {
    date.setDate(date.getDate() + 1);
    return toLocalDate(date);
  }
  const weekdays: Array<[string, number]> = [
    ["воскресен", 0],
    ["понедельник", 1],
    ["вторник", 2],
    ["сред", 3],
    ["четверг", 4],
    ["пятниц", 5],
    ["суббот", 6],
  ];
  const weekday = weekdays.find(([name]) => lower.includes(name));
  if (!weekday) return null;
  const delta = (weekday[1] - date.getDay() + 7) % 7;
  date.setDate(date.getDate() + delta);
  return toLocalDate(date);
}

function normalizeDate(
  value: unknown,
  sourceText: string,
  nowIso: string,
): string | null {
  const fromSourceText = dateFromRelativeText(sourceText, nowIso);
  if (fromSourceText) return fromSourceText;
  const candidate = nullableString(value);
  if (candidate && /^\d{4}-\d{2}-\d{2}$/.test(candidate)) return candidate;
  return dateFromRelativeText(candidate ?? "", nowIso);
}

function normalizeConfidence(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return 0.7;
  const normalized = value > 1 && value <= 100 ? value / 100 : value;
  return Math.max(0, Math.min(1, normalized));
}

function inferIntent(
  value: unknown,
  sourceText: string,
  assignee: string | null,
): InterpretedAction["intent"] {
  const allowed = new Set<InterpretedAction["intent"]>([
    "shopping",
    "task",
    "event",
    "assignment",
    "note",
    "unknown",
  ]);
  if (
    typeof value === "string" &&
    allowed.has(value as InterpretedAction["intent"])
  ) {
    return value as InterpretedAction["intent"];
  }
  const lower = sourceText.toLowerCase().replaceAll("ё", "е");
  if (/^(?:у нас\s+)?(?:нет|закончились|купить|купи)\b/.test(lower)) {
    return "shopping";
  }
  if (/(врач|встреч|утренник|секци|идем|идём)/.test(lower)) {
    return "event";
  }
  return assignee ? "assignment" : "task";
}

function normalizeAction(
  value: Record<string, unknown>,
  input: { text: string; familyMembers: string[]; nowIso: string },
): InterpretedAction {
  const assignee = nullableString(value["assignee"]);
  const items = Array.isArray(value["items"])
    ? value["items"]
        .filter((item): item is string => typeof item === "string")
        .map(normalizeShoppingItem)
        .filter(Boolean)
    : [];
  const title = nullableString(value["title"]) ?? input.text.trim();
  const inferredIntent = inferIntent(value["intent"], title, assignee);
  const rawNeedsClarification = Boolean(
    value["needs_clarification"] ?? value["needsClarification"],
  );
  const explicitlyNeedsAssignee =
    /\bкто(?:-то)?\s+должен\b|\bкто\s+должен\b|\bкому\s+поручить\b/iu.test(
      input.text,
    );
  const intent =
    inferredIntent === "task" &&
    !assignee &&
    (rawNeedsClarification || explicitlyNeedsAssignee)
      ? "assignment"
      : inferredIntent;
  const rawClarificationOptions =
    value["clarification_options"] ?? value["clarificationOptions"];
  const needsClarification =
    intent !== "shopping" &&
    (rawNeedsClarification ||
      (intent === "assignment" && !assignee) ||
      (explicitlyNeedsAssignee && !assignee));

  return {
    intent,
    title,
    items,
    date: normalizeDate(value["date"], title, input.nowIso),
    time: normalizeTime(value["time"], title),
    assignee,
    confidence: normalizeConfidence(value["confidence"]),
    needsClarification,
    clarificationQuestion:
      nullableString(
        value["clarification_question"] ?? value["clarificationQuestion"],
      ) ?? (needsClarification ? "Кому поручить?" : null),
    clarificationOptions: needsClarification
      ? input.familyMembers
      : [],
    confirmationText:
      nullableString(
        value["confirmation_text"] ?? value["confirmationText"],
      ) ??
      (intent === "shopping"
        ? "Добавила в покупки"
        : intent === "event"
          ? "Запланировала"
          : assignee
            ? `Передала ${assignee}`
            : "Добавила в дела"),
  };
}

export async function interpretWithGigaChat(input: {
  text: string;
  familyMembers: string[];
  nowIso: string;
}): Promise<Interpretation> {
  const token = await getAccessToken();
  const config = getGigaChatConfig();

  const response = await postWithPinnedCa(
    "completion",
    COMPLETIONS_URL,
    {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
    },
    JSON.stringify({
        model: config.model,
        messages: [
          {
            role: "system",
            content: buildSystemPrompt(input.familyMembers, input.nowIso),
          },
          { role: "user", content: input.text },
        ],
        response_format: {
          type: "json_schema",
          schema: structuredInterpretationSchema,
          strict: true,
        },
        temperature: 0.1,
    }),
    60_000,
  );

  if (!response.ok) {
    throw new GigaChatRequestError(
      "completion",
      `Completion request failed with HTTP ${response.status}`,
      response.status,
    );
  }

  let raw: unknown;
  try {
    const content = readCompletionContent(response.body);
    raw = parseStructuredContent(content);
  } catch (error) {
    if (error instanceof GigaChatRequestError) throw error;
    throw new GigaChatRequestError(
      "structured_output",
      error instanceof Error ? error.message : "Structured output is invalid",
      response.status || null,
    );
  }

  if (!raw || typeof raw !== "object") {
    throw new GigaChatRequestError(
      "structured_output",
      "Structured output is not an object",
      response.status || null,
    );
  }

  const value = Array.isArray(raw)
    ? { actions: raw }
    : (raw as Record<string, unknown>);
  const rawActions = Array.isArray(value["actions"])
    ? value["actions"]
    : [value];
  const actions = rawActions
    .filter(
      (action): action is Record<string, unknown> =>
        Boolean(action) && typeof action === "object" && !Array.isArray(action),
    )
    .map((action) => normalizeAction(action, input));

  try {
    return InterpretIntentResponse.parse({
      actions,
      confirmationText:
        actions.length === 1
          ? actions[0]?.confirmationText
          : `Добавила ${actions.length} действия`,
      provider: "gigachat",
      diagnostic: "GigaChat connected",
    });
  } catch (error) {
    const fields = validationIssueFields(error);
    throw new GigaChatRequestError(
      "structured_output",
      error instanceof Error ? error.message : "Structured output validation failed",
      response.status || null,
      fields,
    );
  }
}

function normalizeShoppingItem(item: string): string {
  const normalized = item
    .trim()
    .toLowerCase()
    .replaceAll("ё", "е")
    .replace(/^(?:item|название|товар)\s*[:=]\s*/iu, "")
    .replace(/^['"`]+|['"`]+$/g, "")
    .replace(/^c(?=[а-я])/u, "с")
    .replace(/^[\s,{}*.;:!?\-•]+|[\s,{}*.;:!?\-•]+$/g, "");
  if (
    !normalized ||
    normalized === "null" ||
    normalized === "undefined" ||
    /^item\s*[:=]?$/iu.test(normalized)
  ) {
    return "";
  }
  const forms: Record<string, string> = {
    молока: "молоко",
    сливок: "сливки",
    масла: "масло",
    яиц: "яйца",
    хлеба: "хлеб",
    сыра: "сыр",
  };
  return forms[normalized] ?? normalized;
}

export function interpretDemo(input: {
  text: string;
  familyMembers: string[];
  nowIso: string;
}): Interpretation {
  const lower = input.text.toLowerCase().replaceAll("ё", "е");
  const compoundMatch = lower.match(
    /^(?:купить|купи)\s+(.+?)\s+и\s+((?:забрать|позвонить|отвезти|оплатить|вызвать|записать)\b.+)$/,
  );
  if (compoundMatch) {
    const items = compoundMatch[1]
      .split(/\s*(?:,| и )\s*/)
      .map(normalizeShoppingItem)
      .filter(Boolean);
    const secondTitle = compoundMatch[2]
      .replace(/\s+кто(?:-то)?\s+должен.*$/i, "")
      .trim();
    const needsAssignee = /\bкто(?:-то)?\b/.test(lower);
    return InterpretIntentResponse.parse({
      actions: [
        {
          intent: "shopping",
          title: "Купить продукты",
          items,
          date: null,
          time: null,
          assignee: null,
          confidence: 0.82,
          needsClarification: false,
          clarificationQuestion: null,
          clarificationOptions: [],
          confirmationText: "Добавила в покупки",
        },
        {
          intent: needsAssignee ? "assignment" : "task",
          title: secondTitle.charAt(0).toUpperCase() + secondTitle.slice(1),
          items: [],
          date: null,
          time: null,
          assignee: null,
          confidence: 0.72,
          needsClarification: needsAssignee,
          clarificationQuestion: needsAssignee ? "Кому поручить?" : null,
          clarificationOptions: needsAssignee ? input.familyMembers : [],
          confirmationText: needsAssignee
            ? "Сохранила без исполнителя"
            : "Добавила в дела",
        },
      ],
      confirmationText: "Добавила 2 действия",
      provider: "demo_fallback",
      diagnostic: "demo fallback",
    });
  }
  const shoppingMatch = lower.match(
    /^(?:у нас\s+)?(?:нет|закончились|купить|купи)\s+(.+)$/,
  );
  if (shoppingMatch) {
    const items = shoppingMatch[1]
      .split(/\s*(?:,| и )\s*/)
      .map(normalizeShoppingItem)
      .filter(Boolean);
    return InterpretIntentResponse.parse({
      actions: [{
        intent: "shopping",
        title: items.join(", "),
        items,
        date: null,
        time: null,
        assignee: null,
        confidence: 0.82,
        needsClarification: false,
        clarificationQuestion: null,
        clarificationOptions: [],
        confirmationText: "Добавила в покупки",
      }],
      confirmationText: "Добавила в покупки",
      provider: "demo_fallback",
      diagnostic: "demo fallback",
    });
  }

  const assignee =
    input.familyMembers.find((member) =>
      lower.includes(member.toLowerCase().replaceAll("ё", "е")),
    ) ?? null;
  const timeMatch = lower.match(/\b(?:в\s*)?([01]?\d|2[0-3]):([0-5]\d)\b/);
  const baseDate = new Date(input.nowIso);
  const tomorrow = new Date(baseDate);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const date = lower.includes("завтра")
    ? tomorrow.toISOString().slice(0, 10)
    : null;
  const event = /(врач|встреч|утренник|секци|идем|идём)/.test(lower);
  const intent = event ? "event" : assignee ? "assignment" : "task";

  return InterpretIntentResponse.parse({
    actions: [{
      intent,
      title: input.text.trim(),
      items: [],
      date,
      time: timeMatch ? `${timeMatch[1].padStart(2, "0")}:${timeMatch[2]}` : null,
      assignee,
      confidence: 0.68,
      needsClarification: false,
      clarificationQuestion: null,
      clarificationOptions: [],
      confirmationText:
        intent === "event"
          ? "Запланировала"
          : assignee
            ? `Передала ${assignee}`
            : "Добавила в дела",
    }],
    confirmationText:
      intent === "event"
        ? "Запланировала"
        : assignee
          ? `Передала ${assignee}`
          : "Добавила в дела",
    provider: "demo_fallback",
    diagnostic: "demo fallback",
  });
}
