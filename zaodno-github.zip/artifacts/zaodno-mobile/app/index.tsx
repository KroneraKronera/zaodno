import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import React, { useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Keyboard,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import {
  FamilyTask,
  ZaodnoSnapshot,
  useZaodno,
} from '@/context/ZaodnoContext';
import {
  getGetGigaChatStatusQueryKey,
  type Interpretation,
  useGetGigaChatStatus,
  useInterpretIntent,
} from '@workspace/api-client-react';

type Screen = 'today' | 'tasks' | 'shopping' | 'family';
type TaskFilter = 'all' | 'today' | 'assigned' | 'open' | 'done';
const OFFER_TO_ALL = 'Предложить всем';

function formatDate(date = new Date()) {
  return new Intl.DateTimeFormat('ru-RU', {
    day: 'numeric',
    month: 'long',
  }).format(date);
}

function localDate(date = new Date()) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function dateLabel(date?: string) {
  if (!date) return 'Без срока';
  if (date === localDate()) return 'Сегодня';
  return new Intl.DateTimeFormat('ru-RU', {
    day: 'numeric',
    month: 'short',
  }).format(new Date(`${date}T12:00:00`));
}

function iconForKind(kind: FamilyTask['kind']) {
  if (kind === 'event') return 'calendar';
  if (kind === 'assignment') return 'send';
  return 'check-circle';
}

function TaskRow({
  task,
  onToggle,
  onAssign,
  showDate = false,
}: {
  task: FamilyTask;
  onToggle: () => void;
  onAssign?: () => void;
  showDate?: boolean;
}) {
  const colors = useColors();
  const isDone = task.status === 'done';
  const meta = showDate
    ? [
        dateLabel(task.date),
        task.time,
        task.assignee === 'Яна'
          ? 'Вы'
          : task.assignee || (task.status === 'needs-assignee' ? 'Нужен исполнитель' : 'Без исполнителя'),
      ]
        .filter(Boolean)
        .join(' · ')
    : `${task.assignee === 'Яна'
      ? 'Вы'
      : task.assignee || (task.status === 'needs-assignee' ? 'Нужен исполнитель' : 'Без исполнителя')}${
        task.time ? ` · ${task.time}` : ''
      }`;
  return (
    <View style={styles.taskRow}>
      <Pressable
        testID={`task-toggle-${task.id}`}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: isDone }}
        onPress={() => {
          Haptics.selectionAsync();
          onToggle();
        }}
        style={({ pressed }) => [
          styles.checkButton,
          { borderColor: isDone ? colors.primary : colors.border },
          isDone && { backgroundColor: colors.primary },
          pressed && styles.pressed,
        ]}
      >
        {isDone ? (
          <Feather name="check" size={14} color={colors.primaryForeground} />
        ) : null}
      </Pressable>
      <View style={styles.taskCopy}>
        <Text
          style={[
            styles.taskTitle,
            { color: colors.foreground },
            isDone && styles.doneText,
          ]}
        >
          {task.title}
        </Text>
        <View style={styles.metaLine}>
          <Feather
            name={iconForKind(task.kind)}
            size={12}
            color={colors.mutedForeground}
          />
          <Text style={[styles.taskMeta, { color: colors.mutedForeground }]}>
            {meta}
          </Text>
        </View>
        {task.status === 'needs-assignee' && onAssign ? (
          <Pressable
            testID={`assign-task-${task.id}`}
            onPress={onAssign}
            style={({ pressed }) => [
              styles.assignInline,
              { backgroundColor: colors.secondary },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.assignInlineText, { color: colors.primary }]}>
              Назначить
            </Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.emptyState}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Feather name={icon} size={22} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.mutedForeground }]}>
        {description}
      </Text>
    </View>
  );
}

function BrandMark() {
  return (
    <Image
      accessibilityLabel="Заодно"
      resizeMode="contain"
      source={require('../assets/images/zaodno-logo.png')}
      style={styles.brandMark}
    />
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const inputRef = useRef<TextInput>(null);
  const [screen, setScreen] = useState<Screen>('today');
  const [taskFilter, setTaskFilter] = useState<TaskFilter>('all');
  const [input, setInput] = useState('');
  const [isInterpreting, setIsInterpreting] = useState(false);
  const [interpretation, setInterpretation] = useState<Interpretation | null>(null);
  const [providerError, setProviderError] = useState<string | null>(null);
  const [undoSnapshot, setUndoSnapshot] = useState<ZaodnoSnapshot | null>(null);
  const [assigneeQueue, setAssigneeQueue] = useState<string[]>([]);
  const [shoppingInput, setShoppingInput] = useState('');
  const [familyInput, setFamilyInput] = useState('');
  const {
    isHydrated,
    family,
    tasks,
    shopping,
    applyCaptureActions,
    updateTaskAssignee,
    toggleTask,
    addShoppingItems,
    toggleShopping,
    removeShopping,
    clearCompletedShopping,
    addFamilyMember,
    removeFamilyMember,
    restoreSnapshot,
  } = useZaodno();
  const gigaChatStatus = useGetGigaChatStatus({
    query: {
      queryKey: getGetGigaChatStatusQueryKey(),
      retry: false,
      staleTime: 5 * 60 * 1000,
    },
  });
  const interpretIntent = useInterpretIntent();

  const todayTasks = useMemo(
    () =>
      tasks
        .filter((task) => task.status !== 'done' && (task.date === localDate() || !task.date))
        .sort((first, second) => {
          if (!!first.date !== !!second.date) return first.date ? -1 : 1;
          return (first.time || '99:99').localeCompare(second.time || '99:99');
        }),
    [tasks],
  );
  const filteredTasks = useMemo(
    () =>
      tasks.filter((task) => {
        if (taskFilter === 'today') return task.date === localDate() && task.status !== 'done';
        if (taskFilter === 'assigned') return !!task.assignee && task.status !== 'done';
        if (taskFilter === 'open') return task.status !== 'done';
        if (taskFilter === 'done') return task.status === 'done';
        return true;
      }),
    [taskFilter, tasks],
  );
  const openShopping = shopping.filter((item) => !item.done);
  const providerDiagnostic =
    providerError ??
    gigaChatStatus.data?.diagnostic ??
    (gigaChatStatus.isError ? 'GigaChat error' : 'Проверка GigaChat…');
  const providerIsError =
    providerDiagnostic.startsWith('GigaChat error');
  const providerIsDemo = providerDiagnostic === 'demo fallback';
  const assigneeTaskId = assigneeQueue[0] ?? null;
  const assigneeTask = tasks.find((task) => task.id === assigneeTaskId);
  const resultDetail = interpretation?.actions
    .map((action) =>
      action.intent === 'shopping' ? action.items.join(', ') : action.title,
    )
    .join(' · ');

  const openAssigneePicker = (taskId: string) => {
    setAssigneeQueue((current) =>
      current.includes(taskId) ? current : [taskId, ...current],
    );
  };

  const submitCapture = async (value: string) => {
    const text = value.trim();
    if (!text || isInterpreting || !isHydrated) return;
    Keyboard.dismiss();
    setIsInterpreting(true);
    setInterpretation(null);
    setProviderError(null);
    setAssigneeQueue([]);
    const before: ZaodnoSnapshot = {
      tasks: tasks.map((task) => ({ ...task })),
      shopping: shopping.map((item) => ({ ...item })),
    };
    try {
      const result = await interpretIntent.mutateAsync({
        data: {
          text,
          familyMembers: family,
          nowIso: new Date().toISOString(),
        },
      });
      setInterpretation(result);
      const mutatesState = result.actions.some((action) =>
        ['shopping', 'task', 'event', 'assignment'].includes(action.intent),
      );
      const applied = await applyCaptureActions(result.actions);
      setUndoSnapshot(mutatesState ? before : null);
      setInput('');
      if (applied.needsAssigneeTaskIds.length) {
        setAssigneeQueue(applied.needsAssigneeTaskIds);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      const data = (error as {
        data?: { diagnostic?: string; message?: string };
      }).data;
      setProviderError(
        data?.diagnostic === 'GigaChat error'
          ? `GigaChat error${data.message ? ` · ${data.message}` : ''}`
          : 'GigaChat error · сервер недоступен',
      );
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsInterpreting(false);
    }
  };

  const confirmClarification = async (assignee: string) => {
    if (!assigneeTaskId) return;
    if (assignee !== 'Решить позже') {
      await updateTaskAssignee(
        assigneeTaskId,
        assignee === OFFER_TO_ALL ? 'Все' : assignee,
      );
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setAssigneeQueue((current) => current.filter((id) => id !== assigneeTaskId));
  };

  const undoLast = () => {
    if (!undoSnapshot) return;
    restoreSnapshot(undoSnapshot);
    setUndoSnapshot(null);
    setInterpretation(null);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const quickCapture = (text: string) => {
    setInput(text);
    submitCapture(text);
  };

  const changeScreen = (next: Screen) => {
    Haptics.selectionAsync();
    setScreen(next);
    setInterpretation(null);
    setProviderError(null);
    setAssigneeQueue([]);
  };

  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={[colors.background, colors.secondary, colors.background]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.85, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 8, paddingBottom: 112 + bottomInset },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <View style={styles.brand}>
            <BrandMark />
            <View>
              <Text style={[styles.brandName, { color: colors.foreground }]}>Заодно</Text>
              <Text style={[styles.brandTagline, { color: colors.mutedForeground }]}>
                семейный помощник
              </Text>
            </View>
          </View>
          <Pressable
            testID="profile-button"
            onPress={() => changeScreen('family')}
            style={({ pressed }) => [
              styles.avatar,
              { backgroundColor: colors.card, borderColor: colors.border },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.avatarText, { color: colors.primary }]}>Я</Text>
          </Pressable>
        </View>

        {screen === 'today' ? (
          <>
            <View style={[styles.captureCard, { backgroundColor: colors.card }]}>
              <View style={styles.captureHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eyebrow, { color: colors.primary }]}>Всё под контролем</Text>
                  <Text style={[styles.captureTitle, { color: colors.foreground }]}>
                    Что нужно сделать?
                  </Text>
                </View>
                <Pressable
                  testID="voice-button"
                  accessibilityLabel="Голосовой ввод"
                  onPress={() => inputRef.current?.focus()}
                  style={({ pressed }) => [
                    styles.micButton,
                    { backgroundColor: colors.primary },
                    pressed && styles.pressed,
                  ]}
                >
                  <Ionicons name="mic-outline" size={24} color={colors.primaryForeground} />
                </Pressable>
              </View>
              <TextInput
                ref={inputRef}
                testID="capture-input"
                value={input}
                onChangeText={setInput}
                onSubmitEditing={() => submitCapture(input)}
                returnKeyType="done"
                placeholder="Напишите, что происходит…"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.captureInput, { color: colors.foreground }]}
              />
              <View style={styles.chips}>
                <Pressable
                  testID="quick-buy"
                  onPress={() => quickCapture('Закончились молоко и яйца')}
                  style={({ pressed }) => [
                    styles.chip,
                    { backgroundColor: colors.secondary },
                    pressed && styles.pressed,
                  ]}
                >
                  <Feather name="shopping-bag" size={14} color={colors.primary} />
                  <Text style={[styles.chipText, { color: colors.secondaryForeground }]}>Купить</Text>
                </Pressable>
                <Pressable
                  testID="quick-remember"
                  onPress={() => quickCapture('Завтра нужно позвонить бабушке')}
                  style={({ pressed }) => [
                    styles.chip,
                    { backgroundColor: colors.secondary },
                    pressed && styles.pressed,
                  ]}
                >
                  <Feather name="bookmark" size={14} color={colors.primary} />
                  <Text style={[styles.chipText, { color: colors.secondaryForeground }]}>Запомнить</Text>
                </Pressable>
                <Pressable
                  testID="quick-assign"
                  onPress={() => quickCapture('Пусть Саша завтра заберёт Машу')}
                  style={({ pressed }) => [
                    styles.chip,
                    { backgroundColor: colors.secondary },
                    pressed && styles.pressed,
                  ]}
                >
                  <Feather name="send" size={14} color={colors.primary} />
                  <Text style={[styles.chipText, { color: colors.secondaryForeground }]}>Поручить</Text>
                </Pressable>
              </View>
            </View>
            <View testID="gigachat-status" style={styles.providerStatus}>
              <View
                style={[
                  styles.providerDot,
                  {
                    backgroundColor: providerIsError
                      ? colors.destructive
                      : providerIsDemo
                        ? colors.accentForeground
                        : colors.primary,
                  },
                ]}
              />
              <Text
                style={[
                  styles.providerText,
                  {
                    color: providerIsError
                      ? colors.destructive
                      : colors.mutedForeground,
                  },
                ]}
              >
                {providerDiagnostic}
              </Text>
            </View>

            {isInterpreting ? (
              <View style={[styles.resultCard, { backgroundColor: colors.card }]}>
                <ActivityIndicator size="small" color={colors.primary} />
                <Text style={[styles.resultText, { color: colors.foreground }]}>Разбираю вашу мысль…</Text>
              </View>
            ) : null}

            {interpretation || assigneeTask ? (
              <View style={[styles.resultCard, { backgroundColor: colors.card }]}>
                <View style={[styles.resultIcon, { backgroundColor: assigneeTask ? colors.accent : colors.secondary }]}>
                  <Feather
                    name={assigneeTask ? 'help-circle' : 'check'}
                    size={18}
                    color={assigneeTask ? colors.accentForeground : colors.primary}
                  />
                </View>
                <View style={styles.resultBody}>
                  <Text style={[styles.resultText, { color: colors.foreground }]}>
                    {assigneeTask ? 'Кому поручить?' : interpretation?.confirmationText}
                  </Text>
                  <Text style={[styles.resultDetail, { color: colors.mutedForeground }]}>
                    {assigneeTask?.title ?? resultDetail}
                  </Text>
                  {interpretation ? (
                    <Text
                      testID="interpretation-provider"
                      style={[
                        styles.resultDiagnostic,
                        {
                          color:
                            interpretation.provider === 'gigachat'
                              ? colors.primary
                              : colors.accentForeground,
                        },
                      ]}
                    >
                      {interpretation.diagnostic}
                    </Text>
                  ) : null}
                  {assigneeTask ? (
                    <View style={styles.options}>
                      {[...family, OFFER_TO_ALL, 'Решить позже'].map((option) => (
                        <Pressable
                          key={option}
                          testID={`clarification-${option}`}
                          onPress={() => confirmClarification(option)}
                          style={({ pressed }) => [
                            styles.option,
                            { backgroundColor: colors.secondary },
                            pressed && styles.pressed,
                          ]}
                        >
                          <Text style={[styles.optionText, { color: colors.secondaryForeground }]}>{option}</Text>
                        </Pressable>
                      ))}
                    </View>
                  ) : null}
                  {undoSnapshot ? (
                    <Pressable
                      testID="undo-action"
                      onPress={undoLast}
                      style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]}
                    >
                      <Feather name="corner-up-left" size={13} color={colors.primary} />
                      <Text style={[styles.undoText, { color: colors.primary }]}>Отменить</Text>
                    </Pressable>
                  ) : null}
                </View>
              </View>
            ) : null}

            <View style={styles.sectionHeading}>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Сегодня</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  {formatDate()}
                </Text>
              </View>
              <View style={[styles.countBadge, { backgroundColor: colors.accent }]}>
                <Text style={[styles.countText, { color: colors.accentForeground }]}>
                  {todayTasks.length}
                </Text>
              </View>
            </View>
            <View style={[styles.listCard, { backgroundColor: colors.card }]}>
              {todayTasks.length ? (
                todayTasks.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    onToggle={() => toggleTask(task.id)}
                    onAssign={() => openAssigneePicker(task.id)}
                  />
                ))
              ) : (
                <EmptyState
                  icon="sun"
                  title="На сегодня всё"
                  description="Ничего не требует внимания"
                />
              )}
            </View>
            <Pressable
              testID="shopping-summary"
              onPress={() => changeScreen('shopping')}
              style={({ pressed }) => [
                styles.summaryCard,
                { backgroundColor: colors.card },
                pressed && styles.pressed,
              ]}
            >
              <View style={[styles.summaryIcon, { backgroundColor: colors.accent }]}>
                <Feather name="shopping-bag" size={18} color={colors.accentForeground} />
              </View>
              <View style={styles.summaryCopy}>
                <Text style={[styles.summaryTitle, { color: colors.foreground }]}>Покупки</Text>
                <Text style={[styles.summarySubtitle, { color: colors.mutedForeground }]} numberOfLines={1}>
                  {openShopping.length
                    ? `${openShopping.length} ${openShopping.length === 1 ? 'товар' : 'товара'} ждёт в списке`
                    : 'Список пуст'}
                </Text>
              </View>
              <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
            </Pressable>
          </>
        ) : null}

        {screen === 'tasks' ? (
          <>
            <View style={styles.pageHeading}>
              <Text style={[styles.pageTitle, { color: colors.foreground }]}>Дела</Text>
              <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
                Все семейные задачи в одном месте
              </Text>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filterRow}
            >
              {([
                ['all', 'Все'],
                ['today', 'Сегодня'],
                ['assigned', 'Поручено'],
                ['open', 'Открытые'],
                ['done', 'Завершенные'],
              ] as const).map(([filter, label]) => (
                <Pressable
                  key={filter}
                  testID={`task-filter-${filter}`}
                  onPress={() => setTaskFilter(filter)}
                  style={({ pressed }) => [
                    styles.filterPill,
                    { backgroundColor: taskFilter === filter ? colors.primary : colors.card },
                    pressed && styles.pressed,
                  ]}
                >
                  <Text
                    style={[
                      styles.filterText,
                      { color: taskFilter === filter ? colors.primaryForeground : colors.mutedForeground },
                    ]}
                  >
                    {label}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={[styles.listCard, { backgroundColor: colors.card }]}>
              {filteredTasks.length ? (
                filteredTasks.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    showDate
                    onToggle={() => toggleTask(task.id)}
                    onAssign={() => openAssigneePicker(task.id)}
                  />
                ))
              ) : (
                <EmptyState
                  icon={taskFilter === 'done' ? 'archive' : 'check-square'}
                  title={taskFilter === 'done' ? 'Завершённых дел нет' : 'Ничего не найдено'}
                  description={taskFilter === 'done' ? 'Готовые дела появятся здесь' : 'Попробуйте другой фильтр'}
                />
              )}
            </View>
          </>
        ) : null}

        {screen === 'shopping' ? (
          <>
            <View style={styles.pageHeading}>
              <View style={styles.pageHeadingLine}>
                <View>
                  <Text style={[styles.pageTitle, { color: colors.foreground }]}>Покупки</Text>
                  <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
                    Всё, что нужно не забыть в магазине
                  </Text>
                </View>
                {shopping.some((item) => item.done) ? (
                  <Pressable
                    testID="clear-bought"
                    onPress={clearCompletedShopping}
                    style={({ pressed }) => [styles.clearButton, pressed && styles.pressed]}
                  >
                    <Text style={[styles.clearText, { color: colors.primary }]}>Очистить купленное</Text>
                  </Pressable>
                ) : null}
              </View>
            </View>
            <View style={[styles.addRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <TextInput
                testID="shopping-input"
                value={shoppingInput}
                onChangeText={setShoppingInput}
                onSubmitEditing={() => {
                  if (shoppingInput.trim()) addShoppingItems([shoppingInput]);
                  setShoppingInput('');
                }}
                placeholder="Добавить товар"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.addInput, { color: colors.foreground }]}
              />
              <Pressable
                testID="shopping-add"
                onPress={() => {
                  if (shoppingInput.trim()) addShoppingItems([shoppingInput]);
                  setShoppingInput('');
                }}
                style={({ pressed }) => [
                  styles.addButton,
                  { backgroundColor: colors.primary },
                  pressed && styles.pressed,
                ]}
              >
                <Feather name="plus" size={20} color={colors.primaryForeground} />
              </Pressable>
            </View>
            <View style={[styles.listCard, { backgroundColor: colors.card }]}>
              {shopping.length ? (
                shopping.map((item) => (
                  <View key={item.id} style={styles.shoppingRow}>
                    <Pressable
                      testID={`shopping-toggle-${item.id}`}
                      accessibilityRole="checkbox"
                      accessibilityState={{ checked: item.done }}
                      onPress={() => toggleShopping(item.id)}
                      style={({ pressed }) => [
                        styles.checkButton,
                        { borderColor: item.done ? colors.primary : colors.border },
                        item.done && { backgroundColor: colors.primary },
                        pressed && styles.pressed,
                      ]}
                    >
                      {item.done ? <Feather name="check" size={14} color={colors.primaryForeground} /> : null}
                    </Pressable>
                    <Text style={[styles.shoppingText, { color: colors.foreground }, item.done && styles.doneText]}>
                      {item.title}
                    </Text>
                    <Pressable
                      testID={`shopping-remove-${item.id}`}
                      accessibilityLabel={`Удалить ${item.title}`}
                      onPress={() => removeShopping(item.id)}
                      hitSlop={10}
                      style={({ pressed }) => pressed && styles.pressed}
                    >
                      <Feather name="x" size={18} color={colors.mutedForeground} />
                    </Pressable>
                  </View>
                ))
              ) : (
                <EmptyState icon="shopping-bag" title="Список пуст" description="Добавляйте покупки голосом или вручную" />
              )}
            </View>
          </>
        ) : null}

        {screen === 'family' ? (
          <>
            <View style={styles.pageHeading}>
              <Text style={[styles.pageTitle, { color: colors.foreground }]}>Семья</Text>
              <Text style={[styles.pageSubtitle, { color: colors.mutedForeground }]}>
                Люди, которым можно поручить дело
              </Text>
            </View>
            <View style={[styles.familyHero, { backgroundColor: colors.primary }]}>
              <View style={[styles.familyHeroIcon, { backgroundColor: colors.card }]}>
                <Feather name="users" size={22} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.familyHeroTitle, { color: colors.primaryForeground }]}>Вместе проще</Text>
                <Text style={[styles.familyHeroText, { color: colors.secondary }]}>Назначайте дела тем, кто рядом</Text>
              </View>
            </View>
            <View style={[styles.addRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <TextInput
                testID="family-input"
                value={familyInput}
                onChangeText={setFamilyInput}
                onSubmitEditing={() => {
                  if (familyInput.trim()) addFamilyMember(familyInput);
                  setFamilyInput('');
                }}
                placeholder="Имя участника"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.addInput, { color: colors.foreground }]}
              />
              <Pressable
                testID="family-add"
                onPress={() => {
                  if (familyInput.trim()) addFamilyMember(familyInput);
                  setFamilyInput('');
                }}
                style={({ pressed }) => [
                  styles.addButton,
                  { backgroundColor: colors.primary },
                  pressed && styles.pressed,
                ]}
              >
                <Feather name="plus" size={20} color={colors.primaryForeground} />
              </Pressable>
            </View>
            <View style={[styles.listCard, { backgroundColor: colors.card }]}>
              {family.map((member, index) => (
                <View key={member} style={styles.memberRow}>
                  <View style={[styles.memberAvatar, { backgroundColor: index % 2 === 0 ? colors.secondary : colors.accent }]}>
                    <Text style={[styles.memberInitial, { color: index % 2 === 0 ? colors.primary : colors.accentForeground }]}>
                      {member.slice(0, 1)}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.memberName, { color: colors.foreground }]}>{member}</Text>
                    <Text style={[styles.memberRole, { color: colors.mutedForeground }]}>
                      {member === 'Яна' ? 'Это вы' : 'Участник семьи'}
                    </Text>
                  </View>
                  {member !== 'Яна' ? (
                    <Pressable
                      testID={`family-remove-${member}`}
                      accessibilityLabel={`Удалить ${member}`}
                      onPress={() => removeFamilyMember(member)}
                      hitSlop={10}
                      style={({ pressed }) => pressed && styles.pressed}
                    >
                      <Feather name="more-horizontal" size={20} color={colors.mutedForeground} />
                    </Pressable>
                  ) : null}
                </View>
              ))}
            </View>
          </>
        ) : null}
      </KeyboardAwareScrollViewCompat>

      <View
        style={[
          styles.bottomNav,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            paddingBottom: Math.max(bottomInset, 8),
          },
        ]}
      >
        {([
          ['today', 'home', 'Сегодня'],
          ['tasks', 'check-square', 'Дела'],
          ['shopping', 'shopping-bag', 'Покупки'],
          ['family', 'users', 'Семья'],
        ] as const).map(([key, icon, label]) => (
          <Pressable
            key={key}
            testID={`tab-${key}`}
            onPress={() => changeScreen(key)}
            style={({ pressed }) => [styles.navItem, pressed && styles.pressed]}
          >
            <View style={[styles.navIcon, screen === key && { backgroundColor: colors.secondary }]}>
              <Feather name={icon} size={18} color={screen === key ? colors.primary : colors.mutedForeground} />
            </View>
            <Text style={[styles.navLabel, { color: screen === key ? colors.primary : colors.mutedForeground }]}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 18 },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 22,
    paddingHorizontal: 3,
  },
  brand: { alignItems: 'center', flexDirection: 'row', gap: 10 },
  brandMark: {
    height: 42,
    width: 52,
  },
  brandName: { fontFamily: 'Inter_700Bold', fontSize: 23, letterSpacing: -0.5 },
  brandTagline: { fontFamily: 'Inter_500Medium', fontSize: 12, marginTop: 1 },
  avatar: {
    alignItems: 'center',
    borderRadius: 22,
    borderWidth: 1,
    height: 44,
    justifyContent: 'center',
    width: 44,
  },
  avatarText: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  captureCard: {
    borderRadius: 28,
    elevation: 3,
    padding: 21,
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
  },
  captureHeader: { alignItems: 'center', flexDirection: 'row' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.7, textTransform: 'uppercase' },
  captureTitle: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -1.2, marginTop: 6 },
  micButton: {
    alignItems: 'center',
    borderRadius: 25,
    height: 52,
    justifyContent: 'center',
    width: 52,
  },
  captureInput: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    minHeight: 46,
    paddingHorizontal: 0,
  },
  chips: { flexDirection: 'row', gap: 7, marginTop: 9 },
  chip: { alignItems: 'center', borderRadius: 99, flexDirection: 'row', gap: 6, paddingHorizontal: 11, paddingVertical: 9 },
  chipText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  providerStatus: { alignItems: 'center', flexDirection: 'row', gap: 6, marginLeft: 4, marginTop: 9 },
  providerDot: { borderRadius: 99, height: 6, width: 6 },
  providerText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  resultCard: {
    alignItems: 'flex-start',
    borderRadius: 22,
    flexDirection: 'row',
    gap: 12,
    marginTop: 14,
    padding: 16,
  },
  resultIcon: { alignItems: 'center', borderRadius: 13, height: 34, justifyContent: 'center', width: 34 },
  resultBody: { flex: 1 },
  resultText: { fontFamily: 'Inter_700Bold', fontSize: 14, lineHeight: 19 },
  resultDetail: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 18, marginTop: 2 },
  resultDiagnostic: { fontFamily: 'Inter_600SemiBold', fontSize: 11, marginTop: 6 },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 11 },
  option: { borderRadius: 99, paddingHorizontal: 12, paddingVertical: 9 },
  optionText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  undoButton: { alignItems: 'center', flexDirection: 'row', gap: 5, marginTop: 11 },
  undoText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  sectionHeading: { alignItems: 'flex-end', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 11, marginTop: 27, paddingHorizontal: 3 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 26, letterSpacing: -0.7 },
  sectionSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 3 },
  countBadge: { alignItems: 'center', borderRadius: 99, height: 28, justifyContent: 'center', minWidth: 28, paddingHorizontal: 8 },
  countText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  listCard: {
    borderRadius: 24,
    elevation: 2,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.05,
    shadowRadius: 16,
  },
  taskRow: { alignItems: 'center', flexDirection: 'row', gap: 12, minHeight: 70, paddingHorizontal: 17, paddingVertical: 11 },
  checkButton: { alignItems: 'center', borderRadius: 99, borderWidth: 1.5, height: 25, justifyContent: 'center', width: 25 },
  taskCopy: { flex: 1 },
  assignInline: {
    alignSelf: 'flex-start',
    borderRadius: 99,
    marginTop: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  assignInlineText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  taskTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 19 },
  taskMeta: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  metaLine: { alignItems: 'center', flexDirection: 'row', gap: 5, marginTop: 4 },
  doneText: { textDecorationLine: 'line-through' },
  emptyState: { alignItems: 'center', paddingHorizontal: 28, paddingVertical: 27 },
  emptyIcon: { alignItems: 'center', borderRadius: 18, height: 48, justifyContent: 'center', marginBottom: 10, width: 48 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  emptyDescription: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 4, textAlign: 'center' },
  summaryCard: { alignItems: 'center', borderRadius: 23, flexDirection: 'row', gap: 12, marginTop: 12, padding: 16 },
  summaryIcon: { alignItems: 'center', borderRadius: 14, height: 38, justifyContent: 'center', width: 38 },
  summaryCopy: { flex: 1 },
  summaryTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  summarySubtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 3 },
  pageHeading: { marginBottom: 19, paddingHorizontal: 3 },
  pageHeadingLine: { alignItems: 'flex-end', flexDirection: 'row', justifyContent: 'space-between' },
  pageTitle: { fontFamily: 'Inter_700Bold', fontSize: 32, letterSpacing: -1 },
  pageSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, marginTop: 5 },
  clearButton: { paddingBottom: 2, paddingLeft: 10 },
  clearText: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textAlign: 'right' },
  filterRow: { gap: 7, paddingBottom: 12, paddingTop: 1 },
  filterPill: { borderRadius: 99, paddingHorizontal: 13, paddingVertical: 9 },
  filterText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  addRow: { alignItems: 'center', borderRadius: 20, borderWidth: 1, flexDirection: 'row', marginBottom: 12, paddingLeft: 16, paddingRight: 7 },
  addInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 14, minHeight: 49 },
  addButton: { alignItems: 'center', borderRadius: 15, height: 36, justifyContent: 'center', width: 36 },
  shoppingRow: { alignItems: 'center', flexDirection: 'row', gap: 12, minHeight: 58, paddingHorizontal: 17 },
  shoppingText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  familyHero: { alignItems: 'center', borderRadius: 24, flexDirection: 'row', gap: 13, marginBottom: 12, padding: 18 },
  familyHeroIcon: { alignItems: 'center', borderRadius: 16, height: 42, justifyContent: 'center', width: 42 },
  familyHeroTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  familyHeroText: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 3 },
  memberRow: { alignItems: 'center', flexDirection: 'row', gap: 12, minHeight: 70, paddingHorizontal: 17 },
  memberAvatar: { alignItems: 'center', borderRadius: 17, height: 36, justifyContent: 'center', width: 36 },
  memberInitial: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  memberName: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  memberRole: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 3 },
  bottomNav: {
    alignItems: 'flex-start',
    borderRadius: 24,
    borderWidth: 1,
    bottom: 9,
    flexDirection: 'row',
    justifyContent: 'space-around',
    left: 14,
    paddingTop: 8,
    position: 'absolute',
    right: 14,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 22,
  },
  navItem: { alignItems: 'center', flex: 1, gap: 2 },
  navIcon: { alignItems: 'center', borderRadius: 13, height: 29, justifyContent: 'center', width: 44 },
  navLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  pressed: { opacity: 0.72 },
});