# Заодно

Русскоязычный мобильный прототип семейного помощника на Expo с backend-сервисом для интерпретации запросов через GigaChat.

## Быстрый запуск

```bash
pnpm install
pnpm --filter @workspace/api-spec run codegen
pnpm --filter @workspace/api-server run dev
```

В отдельном терминале запустите мобильный клиент:

```bash
pnpm --filter @workspace/zaodno-mobile run dev
```

Для работы GigaChat задайте переменные окружения вне репозитория:

- `GIGACHAT_AUTH_KEY`
- `GIGACHAT_SCOPE`
- `SESSION_SECRET`

Секреты нельзя добавлять в GitHub. В Replit их следует хранить в Secrets.

## Структура

- `artifacts/api-server` — TypeScript API-сервис и интеграция GigaChat
- `artifacts/zaodno-mobile` — Expo-приложение
- `lib/api-spec` — OpenAPI-спецификация и codegen
- `lib/api-client-react`, `lib/api-zod` — сгенерированные API-клиент и схемы

## Проверка типов

```bash
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/zaodno-mobile run typecheck
```
